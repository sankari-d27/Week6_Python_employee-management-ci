"""Employee Management System package."""
